#include <stdio.h>

int main()
{
	printf("%d\n", '-');

	return 0;
}//mmain

