int main()
{
	int i = -123456;

	i *= -1;

	return 0;
}//main

