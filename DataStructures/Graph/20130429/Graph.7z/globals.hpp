#pragma once

struct DefaultEdgeInfo {};

struct DefaultVertexInfo {};

struct DefaultGraphInfo {};

